# Python program for evaluation one trainee in a bootcamp
trainee_name = input("Enter the name of the trainee:")
pythonsyntax = float(input("Enter the trainee score in Python syntax: "))
problem_solving = float(input("Enter the trainee score in problem solving: "))
mini_project = float(input("Enter the trainee score in mini project: "))
#calculate the total and average score
total_score = pythonsyntax + problem_solving + mini_project
average_score = total_score / 3
# determine performance grade
if average_score >= 80:
    performance_grade = "Excellent"
elif average_score >= 70:
    performance_grade = "Very Good"
elif average_score >=60:
    performance_grade = "Good"
elif average_score >= 50:
    performance_grade = "Fair"
else:
    performance_grade = "Needs Improvement"
#determine the completion status 
if average_score >= 50:
    completion_status = "Completed"
else:
    completion_status = "Not Completed"
#Display the report
print("\n========================================")
print("Python Bootcamp Trainee Report")
print("========================================\n")
print("Trainee Name:", trainee_name)
print("Python Syntax Score:", pythonsyntax)
print("Problem Solving Score:", problem_solving)
print("Mini Project Score:", mini_project)
print("Total Score:", total_score)
print("Average Score:", average_score)
print("Performance Grade:", performance_grade)
print("Completion Status:", completion_status)
print("==============================================")

#Save the data into file
file=open("bootcamp_report.txt","a")
file.write(f"Trainee Name: {trainee_name}\n")
file.write(f"Python Syntax Score: {pythonsyntax}\n")
file.write(f"Problem Solving Score: {problem_solving}\n")
file.write(f"Mini Project Score: {mini_project}\n")
file.write(f"Total Score: {total_score}\n")
file.write(f"Average Score: {average_score}\n")
file.write(f"Performance Grade: {performance_grade}\n")
file.write(f"Completion Status: {completion_status}\n")
file.close()
print("\n Record saved successfully in the Bootcamp_report.txt")